MOTHER 3 Recomp v1.0.4 - Linux x86_64

Run ./Mother3Recomp from this folder. Requires 64-bit Linux with SDL2 (libSDL2-2.0.so.0) and OpenGL (libGL.so.1). On Ubuntu or Debian, install them with: sudo apt install libsdl2-2.0-0 libgl1

The ROM and GBA BIOS are not included. Select files you own in the launcher. Supports clean Japanese ROMs with IPS, IPS32, BPS, or UPS patches, plus supported already-patched ROMs. F10 toggles the bezel, F11 opens the in-game menu, and Escape exits. Fullscreen, widescreen, and analog stick movement are included.
